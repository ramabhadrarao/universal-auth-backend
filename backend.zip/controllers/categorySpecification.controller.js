const CategorySpecification = require('../models/categorySpecification.model');

exports.createCategorySpecification = async (req, res) => {
  try {
    const spec = await CategorySpecification.create(req.body);
    res.status(201).json(spec);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getAllCategorySpecifications = async (req, res) => {
  const list = await CategorySpecification.find().populate('category subcategory');
  res.json(list);
};

exports.updateCategorySpecification = async (req, res) => {
  const updated = await CategorySpecification.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
};

exports.deleteCategorySpecification = async (req, res) => {
  await CategorySpecification.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted successfully' });
};
