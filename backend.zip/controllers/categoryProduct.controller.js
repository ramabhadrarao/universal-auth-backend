const CategoryProduct = require('../models/categoryProduct.model');

exports.createCategoryProduct = async (req, res) => {
  try {
    const product = await CategoryProduct.create(req.body);
    res.status(201).json(product);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getAllCategoryProducts = async (req, res) => {
  const list = await CategoryProduct.find().populate('category subcategory product');
  res.json(list);
};

exports.updateCategoryProduct = async (req, res) => {
  const updated = await CategoryProduct.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
};

exports.deleteCategoryProduct = async (req, res) => {
  await CategoryProduct.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted successfully' });
};
