const CategoryProcedure = require('../models/categoryProcedure.model');

exports.createCategoryProcedure = async (req, res) => {
  try {
    const procedure = await CategoryProcedure.create(req.body);
    res.status(201).json(procedure);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

exports.getAllCategoryProcedures = async (req, res) => {
  const list = await CategoryProcedure.find().populate('category subcategory');
  res.json(list);
};

exports.updateCategoryProcedure = async (req, res) => {
  const updated = await CategoryProcedure.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
};

exports.deleteCategoryProcedure = async (req, res) => {
  await CategoryProcedure.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted successfully' });
};
