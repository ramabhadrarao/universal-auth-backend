const express = require('express');
const router = express.Router();
const controller = require('../controllers/categorySpecification.controller');

router.post('/', controller.createCategorySpecification);
router.get('/', controller.getAllCategorySpecifications);
router.put('/:id', controller.updateCategorySpecification);
router.delete('/:id', controller.deleteCategorySpecification);

module.exports = router;
