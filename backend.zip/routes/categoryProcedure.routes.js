const express = require('express');
const router = express.Router();
const controller = require('../controllers/categoryProcedure.controller');

router.post('/', controller.createCategoryProcedure);
router.get('/', controller.getAllCategoryProcedures);
router.put('/:id', controller.updateCategoryProcedure);
router.delete('/:id', controller.deleteCategoryProcedure);

module.exports = router;
