const express = require('express');
const router = express.Router();
const controller = require('../controllers/categoryProduct.controller');

router.post('/', controller.createCategoryProduct);
router.get('/', controller.getAllCategoryProducts);
router.put('/:id', controller.updateCategoryProduct);
router.delete('/:id', controller.deleteCategoryProduct);

module.exports = router;
